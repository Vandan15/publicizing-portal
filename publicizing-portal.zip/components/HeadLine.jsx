import React from 'react'

export default function HeadLine() {
    return (
        <div className='headline-wrapper container'>
            <h2>Select Blocks for your advertisement</h2>
        </div>
    )
}
